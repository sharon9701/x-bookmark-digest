# Interaction contract

## Modes

- `single`: 默认模式。一次只发送一张卡片，用户回复一个动作后再显示下一张；用户不需要选择卡片序号。
- `batch`: 只有用户明确要求批量时启用。可发送 3 或 5 张，用户按显示顺序回复多行动作。
- 不一次发送整个队列，也不把多条内容压缩成无标题的信息流。

## Card contract

每张卡片包含：

1. `Step n of N` 和真实队列进度；
2. 原贴标题、作者、分类、来源和原帖链接；
3. 所有可用媒体，图片失败时保留媒体链接；
4. 摘要和要点；
5. 四个动作：`1`、`2`、`3`、`4 分类名`。

字数上限属于内部注释校验，不写在卡片标题或要点标题中。

## Single reply parsing

默认模式下，回复只对应当前卡片：

```text
2
```

Agent 根据当前 session 的下一条 ID 生成一个 decision，调用 `review-apply`，成功后再调用 `card --session`。不要要求用户输入或选择卡片编号。

## Batch reply parsing

用户回复按非空行解析，逐行对应当前批次：

```text
2
3
4｜工具与产品
```

也接受空格形式 `4 工具与产品`。只有 `1`、`2`、`3` 和合法的 `4` 分类行有效；数量超过当前批次时停止并要求重新提交。少于当前批次时只处理前几条，剩余卡片保持未完成。

Agent 应先把自然语言解析成 JSON，再调用 `review-batch`，不要把自然语言直接拼接到 shell 命令中：

```json
{
  "decisions": [
    {"id": "tweet-1", "action": "keep"},
    {"id": "tweet-2", "action": "obsidian"},
    {"id": "tweet-3", "action": "category", "category": "工具与产品"}
  ]
}
```

## Failure behavior

- 按队列顺序执行；第一条失败后停止。
- 已成功的决定保留 receipt；失败条目和后续条目不追加 receipt。
- 返回已完成数量、失败 ID、失败原因和下一次应继续的卡片位置。
- 不为了让批次看起来完成而跳过失败条目。
